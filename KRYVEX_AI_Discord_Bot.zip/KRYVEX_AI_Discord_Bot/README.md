# KRYVEX AI Discord Bot

## Features
- AI chat through `/ask`, DMs, and bot mentions
- Code writing, explanations, and debugging
- Reads small text/code attachments (does not execute them)
- Per-user, per-channel conversation history stored in SQLite
- `/reset`, `/help`, `/status`, `/about`, `/setmodel`, `/announce`
- Owner-only announcement command
- Red KRYVEX embeds and basic audit logging

## Requirements
- Python 3.10+
- A Discord bot token
- An OpenAI API key and API access to the selected model

## Setup
1. Install packages:
   `pip install -r requirements.txt`
2. Copy `.env.example` to `.env`.
3. Fill in `DISCORD_TOKEN`, `OPENAI_API_KEY`, and `OWNER_ID`.
4. In the Discord Developer Portal, enable the **Message Content Intent** for the bot.
5. Invite the bot with `bot` and `applications.commands` scopes. Grant only the permissions it needs: View Channels, Send Messages, Read Message History, and Embed Links.
6. Run:
   `python bot.py`

## Important
- Never share your Discord token or OpenAI API key.
- Keep `.env` private and do not upload it to GitHub.
- The bot does not run user-uploaded code or shell commands.
- File analysis currently supports small text/code formats only.
- API usage may incur charges depending on your API account and limits.
- If your account cannot access `gpt-5.5`, set `OPENAI_MODEL` to a model enabled for your API key.
