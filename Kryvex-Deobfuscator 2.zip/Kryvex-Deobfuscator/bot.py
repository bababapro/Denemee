from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import io
import json
import os
import re
import shutil
import signal
import socket
import sqlite3
import tempfile
import time
import urllib.parse
import aiohttp
from datetime import datetime, timezone
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
ENGINE_DIR = BASE_DIR / "engines"
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / "kryvex.sqlite3"

load_dotenv(BASE_DIR / ".env")
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
PREFIX = "."
MAX_FILE_BYTES = 1_000_000
MAX_OUTPUT_BYTES = 7_000_000
MAX_FETCH_BYTES = 2_000_000
JOB_TIMEOUT = 40
MAX_CONCURRENT_JOBS = 2
JOB_SEMAPHORE = asyncio.Semaphore(MAX_CONCURRENT_JOBS)

HEADER = "-- By Kryvex [ https://discord.gg/YPRvTb4Gs ]"
RED = discord.Color.from_rgb(220, 38, 38)
ALLOWED_EXTENSIONS = {".lua", ".luau", ".txt"}

# Only engines whose uploaded implementation is a local, static source transformer
# are enabled here. Runtime-emulation, remote-API, and bytecode-only tools are not
# silently presented as readable-source deobfuscators.
ENGINES = {
    "Clyde": {
        "key": "clyde", "versions": "Clyde V2-V6 (stack/register VM)",
        "command": lambda src, dst: ["node", str(ENGINE_DIR / "clyde" / "cli.js"), str(src), "-o", str(dst)],
        "cwd": ENGINE_DIR / "clyde", "static": True,
    },
    "Hercules": {
        "key": "hercules", "versions": "Hercules 1.6.x, 2.0.0 and 2.0.1 payload formats",
        "command": lambda src, dst: ["python", str(ENGINE_DIR / "hercules" / "hercules" / "deobfhercules_fixed" / "deobfhercules.py"), str(src), str(dst)],
        "cwd": ENGINE_DIR / "hercules", "static": True,
    },
    "Ironveil": {
        "key": "ironveil", "versions": "Ironveil V1",
        "command": lambda src, dst: ["node", str(ENGINE_DIR / "ironveil" / "deobfuscator" / "index.js"), str(src), str(dst)],
        "cwd": ENGINE_DIR / "ironveil" / "deobfuscator", "static": True,
    },
    "Prometheus": {
        "key": "prometheus", "versions": "Prometheus / WeAreDevs fork formats documented by the supplied project",
        "command": lambda src, dst: ["node", str(ENGINE_DIR / "prometheus" / "bin" / "pdeobf.js"), str(src), "-o", str(dst), "-q"],
        "cwd": ENGINE_DIR / "prometheus", "static": True,
    },
}

# High-specificity signatures first. Unknown is intentional: no generic guessing.
DETECTION_RULES = [
    ("Luraph v15", re.compile(r"Luraph\s+Obfuscator\s+v?15\b|luraph_v15", re.I), "high", "version watermark / engine marker"),
    ("Luraph v14", re.compile(r"Luraph\s+Obfuscator\s+v?14\.(?:7|8|9)\b", re.I), "high", "version watermark"),
    ("Luraph", re.compile(r"Luraph\s+Obfuscator|\bLPH_[A-Za-z0-9_]+", re.I), "medium", "Luraph marker"),
    ("Clyde", re.compile(r"clydeprotectionde\.cloud|Clyde\s*(?:Protection|V[2-6])|ClydeObfuscator|clyde_static", re.I), "high", "Clyde watermark / structural marker"),
    ("Hercules", re.compile(r"Obfuscated\s+by\s+Hercules|WrapState\s*\(\s*BcToState", re.I), "high", "Hercules watermark / VM entry shape"),
    ("Ironveil", re.compile(r"Ironveil|ironveil", re.I), "medium", "Ironveil marker"),
    ("LuaObfuscator", re.compile(r"LuaObfuscator|Chaotic\s+Good|Chaotic\s+Evil", re.I), "high", "LuaObfuscator marker"),
    ("Prometheus", re.compile(r"Prometheus|WeAreDevs", re.I), "medium", "Prometheus marker"),
    ("77fuscator", re.compile(r"77FUS\s*\||77fuscator\s+0\.6\.1", re.I), "high", "77fuscator blob / watermark"),
    ("MoonSec V3", re.compile(r"MoonSec\s*(?:V?3)?|MoonSecV3", re.I), "medium", "MoonSec marker"),
    ("IronBrew2", re.compile(r"IronBrew\s*2|Ironbrew2|IronBrew2", re.I), "medium", "IronBrew2 marker"),
    ("Moonveil", re.compile(r"Moonveil", re.I), "medium", "Moonveil marker"),
]


def db_init() -> None:
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            user_tag TEXT NOT NULL,
            command TEXT NOT NULL,
            created_at TEXT NOT NULL,
            result TEXT NOT NULL,
            obfuscator TEXT NOT NULL,
            duration REAL NOT NULL
        )""")
        db.commit()


def log_job(user: discord.abc.User, command: str, result: str, obfuscator: str, duration: float) -> None:
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            "INSERT INTO logs(user_id,user_tag,command,created_at,result,obfuscator,duration) VALUES(?,?,?,?,?,?,?)",
            (user.id, str(user), command, datetime.now(timezone.utc).isoformat(), result, obfuscator, round(duration, 3)),
        )
        db.commit()


def make_embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(title=f"KRYVEX DEOBFUSCATOR | {title}", description=description, color=RED, timestamp=datetime.now(timezone.utc))


def is_log_admin(user: discord.abc.User, guild_permissions=None) -> bool:
    if user.id == OWNER_ID or user.id in ADMIN_IDS:
        return True
    return bool(guild_permissions and getattr(guild_permissions, "manage_guild", False))


def detect_obfuscator(source: str) -> dict:
    sample = source[:250_000]
    for name, pattern, confidence, method in DETECTION_RULES:
        if pattern.search(sample):
            return {"name": name, "confidence": confidence, "method": method}
    return {"name": "Unknown", "confidence": "none", "method": "No supported signature matched"}


async def get_attachment(ctx: commands.Context) -> tuple[str, str]:
    attachment = ctx.message.attachments[0] if ctx.message.attachments else None
    if attachment is None and ctx.message.reference:
        try:
            ref = await ctx.channel.fetch_message(ctx.message.reference.message_id)
            attachment = ref.attachments[0] if ref.attachments else None
        except (discord.HTTPException, AttributeError):
            attachment = None
    if attachment is None:
        raise ValueError("No file attached. Attach a `.lua`, `.luau`, or `.txt` file.")
    if Path(attachment.filename).suffix.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError("Unsupported file type. Upload a `.lua`, `.luau`, or `.txt` file.")
    if attachment.size <= 0 or attachment.size > MAX_FILE_BYTES:
        raise ValueError("File is too large or empty. Maximum file size is 1 MB.")
    raw = await attachment.read(use_cached=True)
    try:
        source = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("The file is not valid UTF-8 text.") from exc
    if "\x00" in source:
        raise ValueError("The uploaded file appears to be binary, not Lua/Luau source.")
    return Path(attachment.filename).name, source


def tokenize_lua(source: str) -> list[tuple[str, str]]:
    # A lightweight lexer for reporting only; it does not parse or execute Lua.
    token_re = re.compile(
        r"(?P<comment>--\[(?:=*)\[.*?\](?:=*)\]|--[^\n]*)|"
        r"(?P<string>\[(?:=*)\[.*?\](?:=*)\]|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*')|"
        r"(?P<ident>[A-Za-z_][A-Za-z0-9_]*)|(?P<number>\b(?:0[xX][0-9A-Fa-f]+|\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)\b)|"
        r"(?P<other>.)", re.S
    )
    out = []
    for m in token_re.finditer(source):
        kind = m.lastgroup or "other"
        out.append((kind, m.group()))
    return out


def static_dump(source: str, filename: str) -> str:
    tokens = tokenize_lua(source)
    identifiers = [v for k, v in tokens if k == "ident"]
    strings = [v for k, v in tokens if k == "string"]
    numbers = [v for k, v in tokens if k == "number"]
    comments = [v for k, v in tokens if k == "comment"]
    funcs = []
    locals_ = []
    for i, (kind, value) in enumerate(tokens):
        if kind == "ident" and value == "function":
            for k, v in tokens[i+1:i+8]:
                if k == "ident":
                    funcs.append(v)
                    break
                if v == "(":
                    break
        if kind == "ident" and value == "local":
            j = i + 1
            if j < len(tokens) and tokens[j][1] == "function":
                j += 1
            while j < len(tokens) and tokens[j][0] in ("ident", "other"):
                k, v = tokens[j]
                if k == "ident": locals_.append(v)
                elif v not in (",", " ", "\t", "\n", "\r"):
                    break
                j += 1
                if j < len(tokens) and tokens[j][1] == "=":
                    break
    def unique(xs):
        return sorted(set(xs), key=str.lower)
    digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
    lines = [
        "KRYVEX STATIC SOURCE REPORT", f"File: {filename}",
        f"Lines: {len(source.splitlines())}", f"Characters: {len(source)}",
        f"SHA-256: {digest}", "", "STRUCTURE",
        f"Function declarations found: {len(funcs)}",
        f"Local declaration identifiers found: {len(locals_)}",
        f"Unique identifiers: {len(set(identifiers))}",
        f"String literals: {len(strings)}", f"Numeric literals: {len(numbers)}",
        f"Comment blocks/lines: {len(comments)}", "", "FUNCTION NAMES",
    ]
    lines += ["- " + x for x in unique(funcs)[:250]] or ["- None detected"]
    lines += ["", "LOCAL IDENTIFIERS"]
    lines += ["- " + x for x in unique(locals_)[:400]] or ["- None detected"]
    lines += ["", "STRING LITERALS (truncated individually to 300 chars)"]
    lines += ["- " + repr(x[:300]) for x in strings[:300]] or ["- None detected"]
    lines += ["", "NUMERIC CONSTANTS"]
    lines += ["- " + x for x in numbers[:300]] or ["- None detected"]
    lines += ["", "STATIC API PATTERNS"]
    patterns = {
        "HTTP / network references": r"\b(HttpGet|HttpPost|RequestAsync|GetAsync|PostAsync)\b",
        "Dynamic loader references": r"\b(loadstring|load|loadfile)\s*\(",
        "Environment references": r"\b(getgenv|getrenv|getfenv|setfenv)\s*\(",
        "Debug library references": r"\bdebug\s*\.",
        "Metatable / hook references": r"\b(getrawmetatable|setreadonly|hookfunction|newcclosure)\s*\(",
        "Roblox service references": r"\bGetService\s*\(",
    }
    for label, pat in patterns.items():
        count = len(re.findall(pat, source, re.I))
        if count:
            lines.append(f"- {label}: {count}")
    lines += ["", "NOTE: Text-based static inspection only. No Lua/Luau code was executed."]
    return "\n".join(lines) + "\n"


def conservative_format(source: str) -> str:
    source = source.replace("\r\n", "\n").replace("\r", "\n")
    lines = [line.rstrip() for line in source.split("\n")]
    out, blank = [], False
    for line in lines:
        if not line.strip():
            if not blank:
                out.append("")
            blank = True
        else:
            out.append(line)
            blank = False
    return "\n".join(out).strip() + "\n"


def safe_rename(source: str) -> tuple[str, int, str]:
    # Regex-only renaming can corrupt Lua scopes, shadowed locals, table keys,
    # and property names. Fail closed until a scope-aware AST resolver is added.
    return conservative_format(source), 0, "No identifiers were renamed: a scope-safe Lua/Luau AST resolver is not bundled."


def validate_public_url(url: str) -> urllib.parse.SplitResult:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ("https", "http") or not parsed.hostname:
        raise ValueError("Only valid HTTP or HTTPS source URLs are accepted.")
    if parsed.username or parsed.password:
        raise ValueError("URLs containing embedded credentials are not allowed.")
    if parsed.port not in (None, 80, 443):
        raise ValueError("Only standard HTTP/HTTPS ports are allowed.")
    if parsed.hostname.lower() in {"localhost", "localhost.localdomain"}:
        raise ValueError("Local or private network addresses are not allowed.")
    try:
        literal = ipaddress.ip_address(parsed.hostname)
    except ValueError:
        literal = None
    if literal is not None and not literal.is_global:
        raise ValueError("Local, private, loopback, link-local, or reserved IP addresses are blocked.")
    return parsed


class PublicResolver(aiohttp.abc.AbstractResolver):
    async def resolve(self, host, port=0, family=socket.AF_UNSPEC):
        loop = asyncio.get_running_loop()
        try:
            infos = await loop.getaddrinfo(host, port, family=family, type=socket.SOCK_STREAM)
        except OSError as exc:
            raise OSError("The URL host could not be resolved.") from exc
        results = []
        seen = set()
        for af, socktype, proto, canonname, sockaddr in infos:
            ip_text = sockaddr[0]
            ip_obj = ipaddress.ip_address(ip_text)
            if not ip_obj.is_global:
                raise OSError("Local, private, loopback, link-local, or reserved IP addresses are blocked.")
            key = (ip_text, af)
            if key in seen:
                continue
            seen.add(key)
            results.append({"hostname": host, "host": ip_text, "port": port,
                            "family": af, "proto": proto, "flags": socket.AI_NUMERICHOST})
        if not results:
            raise OSError("The URL host did not resolve to a public address.")
        return results

    async def close(self):
        return None


async def fetch_public_source(url: str) -> tuple[str, str]:
    current = url
    timeout = aiohttp.ClientTimeout(total=10, connect=5, sock_read=5)
    connector = aiohttp.TCPConnector(resolver=PublicResolver(), use_dns_cache=False, limit=2)
    async with aiohttp.ClientSession(connector=connector, timeout=timeout, trust_env=False,
                                     headers={"User-Agent": "KryvexDeobfuscator/1.0", "Accept": "text/plain,*/*;q=0.5"}) as session:
        for hop in range(4):
            parsed = validate_public_url(current)
            async with session.get(current, allow_redirects=False) as response:
                if response.status in (301, 302, 303, 307, 308):
                    location = response.headers.get("Location")
                    if not location or hop == 3:
                        raise ValueError("The source URL redirected too many times or had an invalid redirect.")
                    current = urllib.parse.urljoin(current, location)
                    continue
                if response.status < 200 or response.status >= 300:
                    raise ValueError(f"The source server returned HTTP {response.status}.")
                data = bytearray()
                async for chunk in response.content.iter_chunked(64 * 1024):
                    data.extend(chunk)
                    if len(data) > MAX_FETCH_BYTES:
                        raise ValueError("The remote source is too large (maximum 2 MB).")
                final = urllib.parse.urlsplit(str(response.url))
                if final.hostname:
                    validate_public_url(str(response.url))
                try:
                    source = bytes(data).decode("utf-8-sig")
                except UnicodeDecodeError as exc:
                    raise ValueError("The remote response is not UTF-8 text.") from exc
                if "\x00" in source:
                    raise ValueError("The remote response is not a text Lua/Luau source file.")
                name = Path(urllib.parse.unquote(final.path)).name or "downloaded_source.lua"
                if Path(name).suffix.lower() not in ALLOWED_EXTENSIONS:
                    name = Path(name).stem + ".lua"
                return name, source
    raise ValueError("The source URL could not be retrieved.")


def extract_loadstring_url(argument: str) -> str:
    match = re.search(r"loadstring\s*\(\s*game\s*:\s*HttpGet\s*\(\s*(['\"])(https?://.+?)\1\s*\)\s*\)", argument, re.I | re.S)
    if match:
        return match.group(2)
    raw = argument.strip().strip("<>")
    if raw.startswith(("https://", "http://")):
        return raw
    raise ValueError('Usage: `.get loadstring(game:HttpGet("https://example.com/script.lua"))()`')


def _resource_limits():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (45, 50))
        resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_OUTPUT_BYTES, MAX_OUTPUT_BYTES))
        resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
        try:
            resource.setrlimit(resource.RLIMIT_AS, (1_500_000_000, 1_500_000_000))
        except (ValueError, OSError):
            pass
    except Exception:
        pass


async def run_engine(engine_name: str, source: str) -> str:
    info = ENGINES[engine_name]
    async with JOB_SEMAPHORE:
        with tempfile.TemporaryDirectory(prefix="kryvex_job_") as td:
            work = Path(td)
            inp, out = work / "input.lua", work / "deobfuscated.lua"
            inp.write_text(source, encoding="utf-8")
            cmd = info["command"](inp, out)
            executable = shutil.which(cmd[0])
            if not executable:
                raise RuntimeError(f"Required runtime `{cmd[0]}` is not installed.")
            cmd[0] = executable
            env = {"PATH": os.environ.get("PATH", ""), "HOME": td, "TMPDIR": td,
                   "PYTHONIOENCODING": "utf-8", "NODE_NO_WARNINGS": "1"}
            kwargs = {"cwd": str(info["cwd"]), "stdout": asyncio.subprocess.PIPE,
                      "stderr": asyncio.subprocess.PIPE, "env": env}
            if os.name == "posix":
                kwargs["preexec_fn"] = _resource_limits
                kwargs["start_new_session"] = True
            proc = await asyncio.create_subprocess_exec(*cmd, **kwargs)
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=JOB_TIMEOUT)
            except asyncio.TimeoutError:
                if os.name == "posix":
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                else:
                    proc.kill()
                await proc.wait()
                raise TimeoutError("Deobfuscation failed: Unable to deobfuscate this file.")
            if proc.returncode != 0 or not out.is_file() or out.stat().st_size == 0:
                detail = (stderr or stdout).decode("utf-8", "replace")[-900:].strip()
                raise RuntimeError(detail or "The selected engine rejected this file or its format is unsupported.")
            if out.stat().st_size > MAX_OUTPUT_BYTES:
                raise RuntimeError("The generated output exceeds the 7 MB output limit.")
            result = out.read_text(encoding="utf-8", errors="replace")
            if not result.strip():
                raise RuntimeError("The selected engine returned an empty result.")
            return result


async def send_lua(ctx: commands.Context, filename: str, content: str, *, title: str, note: str = ""):
    if not content.startswith(HEADER):
        content = HEADER + "\n" + content.lstrip("\n")
    data = content.encode("utf-8")
    if len(data) > MAX_OUTPUT_BYTES:
        return await ctx.reply(embed=make_embed("OUTPUT TOO LARGE", "The generated file exceeds the configured output limit."))
    stem = re.sub(r"[^A-Za-z0-9_.-]", "_", Path(filename).stem)[:60] or "script"
    file = discord.File(io.BytesIO(data), filename=f"Kryvex_{stem}.lua")
    await ctx.reply(content=note or None, embed=make_embed(title, f"Output: `{stem}.lua`"), file=file)


intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None, max_messages=1000)


@bot.event
async def on_ready():
    db_init()
    print(f"Kryvex Deobfuscator online as {bot.user} | prefix={PREFIX}")


@bot.command(name="help")
async def help_command(ctx: commands.Context):
    e = make_embed("COMMANDS", "Lua/Luau static analysis and supported deobfuscation tools.")
    e.add_field(name="`.help`", value="Show this command list.", inline=False)
    e.add_field(name="`.get loadstring(...)()`", value="Fetch a public HTTP/HTTPS Lua source URL and return it as a `.lua` file. Private/local network targets are blocked.", inline=False)
    e.add_field(name="`.detect`", value="Attach a Lua/Luau file to identify a protection signature, confidence, and method.", inline=False)
    e.add_field(name="`.rename`", value="Conservative readability pass. Unsafe identifier rewrites are skipped to preserve program behavior.", inline=False)
    e.add_field(name="`.deobf`", value="Attach a file. Automatically selects a compatible static engine when confidently detected.", inline=False)
    e.add_field(name="`.l`", value="Show recent processing logs. Owner and authorized administrators only.", inline=False)
    e.add_field(name="`.dump`", value="Attach a file to create a static report of functions, identifiers, strings, constants, and API patterns.", inline=False)
    e.set_footer(text="Uploaded Lua/Luau is never executed by the bot. Unsupported engines are reported, not guessed.")
    await ctx.reply(embed=e)


@bot.command(name="detect")
async def detect_command(ctx: commands.Context):
    started = time.monotonic()
    try:
        filename, source = await get_attachment(ctx)
        result = detect_obfuscator(source)
        name = result["name"]
        e = make_embed("DETECTION RESULT", f"**File:** `{filename}`\n**Obfuscator:** `{name}`\n**Confidence:** `{result['confidence'].upper()}`\n**Method:** {result['method']}")
        if name != "Unknown":
            available = ENGINES[name]["versions"] if name in ENGINES else "Detected, but no compatible readable-source engine is enabled."
            e.add_field(name="Engine availability", value=available, inline=False)
        await ctx.reply(embed=e)
        log_job(ctx.author, "detect", "success" if name != "Unknown" else "unknown", name, time.monotonic() - started)
    except Exception as exc:
        await ctx.reply(embed=make_embed("DETECTION FAILED", str(exc)))
        log_job(ctx.author, "detect", "failed", "Unknown", time.monotonic() - started)


@bot.command(name="deobf")
async def deobf_command(ctx: commands.Context):
    started = time.monotonic()
    detected = "Unknown"
    try:
        filename, source = await get_attachment(ctx)
        detected = detect_obfuscator(source)["name"]
        if detected not in ENGINES:
            raise RuntimeError(f"Detected `{detected}`, but no compatible static readable-source engine is enabled for this format.")
        await ctx.reply(embed=make_embed("PROCESSING", f"Detected: `{detected}`\nEngine: `{ENGINES[detected]['versions']}`\nTime limit: {JOB_TIMEOUT} seconds."))
        result = await run_engine(detected, source)
        partial = bool(re.search(r"(?im)^\s*--\s*(?:warning|partial|unresolved):", result))
        note = "Partial reconstruction: the engine reported unresolved sections. Review the output comments." if partial else ""
        await send_lua(ctx, filename, result, title="DEOBFUSCATION COMPLETE", note=note)
        log_job(ctx.author, "deobf", "partial" if partial else "success", detected, time.monotonic() - started)
    except TimeoutError:
        await ctx.reply("Deobfuscation failed: Unable to deobfuscate this file.")
        log_job(ctx.author, "deobf", "timeout", detected, time.monotonic() - started)
    except Exception as exc:
        await ctx.reply(embed=make_embed("DEOBFUSCATION FAILED", str(exc)))
        log_job(ctx.author, "deobf", "failed", detected, time.monotonic() - started)


@bot.command(name="dump")
async def dump_command(ctx: commands.Context):
    started = time.monotonic()
    detected = "Unknown"
    try:
        filename, source = await get_attachment(ctx)
        detected = detect_obfuscator(source)["name"]
        report = static_dump(source, filename)
        await ctx.reply(embed=make_embed("STATIC DUMP", f"**File:** `{filename}`\n**Detected protection:** `{detected}`\nNo source code was executed."), file=discord.File(io.BytesIO(report.encode("utf-8")), filename=f"Kryvex_Dump_{Path(filename).stem}.txt"))
        log_job(ctx.author, "dump", "success", detected, time.monotonic() - started)
    except Exception as exc:
        await ctx.reply(embed=make_embed("DUMP FAILED", str(exc)))
        log_job(ctx.author, "dump", "failed", detected, time.monotonic() - started)


@bot.command(name="rename")
async def rename_command(ctx: commands.Context):
    started = time.monotonic()
    try:
        filename, source = await get_attachment(ctx)
        result, _, note = safe_rename(source)
        await send_lua(ctx, filename, result, title="RENAME / FORMAT RESULT", note=note)
        log_job(ctx.author, "rename", "format-only; no unsafe renames", detect_obfuscator(source)["name"], time.monotonic() - started)
    except Exception as exc:
        await ctx.reply(embed=make_embed("RENAME FAILED", str(exc)))
        log_job(ctx.author, "rename", "failed", "Unknown", time.monotonic() - started)


@bot.command(name="get")
async def get_command(ctx: commands.Context, *, argument: str = ""):
    started = time.monotonic()
    try:
        url = extract_loadstring_url(argument)
        filename, source = await fetch_public_source(url)
        detected = detect_obfuscator(source)["name"]
        if detected in ENGINES:
            result = await run_engine(detected, source)
            await send_lua(ctx, filename, result, title="SOURCE FETCHED AND DEOBFUSCATED", note=f"Detected `{detected}`. The matching static engine completed successfully. No source code was executed.")
            log_job(ctx.author, "get", "deobfuscated", detected, time.monotonic() - started)
        else:
            note = "Source fetched as text only. It was not executed."
            if detected != "Unknown":
                note += f" Detected `{detected}`, but no compatible static readable-source engine is enabled; the original fetched source is attached."
            await send_lua(ctx, filename, source, title="SOURCE FETCHED", note=note)
            log_job(ctx.author, "get", "success" if detected == "Unknown" else "fetched; unsupported protection", detected, time.monotonic() - started)
    except Exception as exc:
        await ctx.reply(embed=make_embed("SOURCE FETCH FAILED", str(exc)))
        log_job(ctx.author, "get", "failed", "Unknown", time.monotonic() - started)


@bot.command(name="l")
async def logs_command(ctx: commands.Context):
    permissions = ctx.author.guild_permissions if isinstance(ctx.author, discord.Member) else None
    if not is_log_admin(ctx.author, permissions):
        return await ctx.reply(embed=make_embed("ACCESS DENIED", "Only the bot owner or an authorized administrator can view logs."))
    with sqlite3.connect(DB_PATH) as db:
        rows = db.execute("SELECT user_tag,command,created_at,result,obfuscator,duration FROM logs ORDER BY id DESC LIMIT 15").fetchall()
    if not rows:
        return await ctx.reply(embed=make_embed("PROCESS LOGS", "No processing logs are available."))
    lines = []
    for user, command, created, result, obf, duration in rows:
        stamp = created.replace("T", " ").split(".")[0]
        lines.append(f"**{discord.utils.escape_markdown(user)}** | `.{command}` | `{stamp} UTC`\nResult: `{result}` | Engine: `{obf}` | `{duration:.2f}s`")
    await ctx.reply(embed=make_embed("RECENT PROCESS LOGS", "\n\n".join(lines)[:4000]))


@bot.event
async def on_command_error(ctx: commands.Context, error: Exception):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.reply(embed=make_embed("MISSING INPUT", "Attach a `.lua`, `.luau`, or `.txt` file, or provide the loadstring URL for `.get`."))
    if isinstance(error, commands.CommandInvokeError):
        error = error.original
    await ctx.reply(embed=make_embed("COMMAND ERROR", f"`{type(error).__name__}`: {str(error)[:250]}"))


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Add it to your .env file.")
    if OWNER_ID <= 0:
        raise SystemExit("OWNER_ID is missing or invalid. Add your Discord user ID to .env.")
    db_init()
    bot.run(TOKEN)
