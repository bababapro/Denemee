# Kryvex Deobfuscator

Python Discord bot with prefix `.`. All bot-facing messages are English.

## Included local static engines

- **Clyde V2-V6** — supplied Node.js static deobfuscator.
- **Hercules 1.6.x / 2.0.0 / 2.0.1** — supplied Python static deobfuscator.
- **Ironveil V1** — supplied Node.js decoder/decompiler.
- **Prometheus / WeAreDevs fork** — supplied Node.js deobfuscator.

The bot does not execute uploaded Lua/Luau source. Engine processes run with per-job temporary folders, a 40-second timeout, output-size checks, and POSIX resource limits where available. These controls are not a substitute for running the bot in a dedicated, restricted container/VM.

## Tools intentionally not auto-connected

- **Luraph v14/v15**: the supplied framework uses runtime tracing / a Luau execution harness. It is excluded because this bot's policy is never to execute uploaded source.
- **LuaObfuscator Chaotic Good/Evil**: the supplied reconstruction pipeline evaluates the protected loader in its custom interpreter. It is excluded from automatic jobs for the same reason.
- **IronBrew2**: supplied project is a separate Discord bot and its decompilation path uses a remote Oracle API/key. It is not a self-contained local CLI adapter.
- **MoonSec V3** and **77fuscator 0.6.1 Early Build**: supplied tools emit Lua 5.1 bytecode (`.luac`) / disassembly, not readable `.lua` source. They are not reported as successful source deobfuscators.
- Other names such as Moonveil, Boronide, Goofyscator, PSU, XHider, and Luast are not enabled because no compatible local readable-source engine was found in the supplied archives.

## Setup

1. Install Python 3.10+ and Node.js 18+.
2. Open a terminal in this folder.
3. Create a virtual environment (recommended): `python -m venv .venv`
4. Activate it and install dependencies: `python -m pip install -r requirements.txt`
5. Copy `.env.example` to `.env`.
6. Put your bot token in `DISCORD_TOKEN` and your Discord user ID in `OWNER_ID`. Optional log administrators go in `ADMIN_IDS`, comma-separated.
7. In the Discord Developer Portal, enable **Message Content Intent** for the bot.
8. Start the bot: `python bot.py`

## Commands

- `.help`
- `.get loadstring(game:HttpGet("https://host/path/script.lua"))()`
- `.detect` + attached `.lua` / `.luau` / `.txt`
- `.rename` + attached source file
- `.deobf` + attached source file
- `.l` — owner / configured administrator / server Manage Server permission only
- `.dump` + attached source file

## Limits and notes

- Input size: 1 MB.
- Remote `.get` response size: 2 MB.
- Deobfuscation timeout: 40 seconds.
- Maximum concurrent engine jobs: 2.
- Maximum output size: 7 MB.
- `.rename` deliberately does not rewrite identifiers yet: the supplied regex-only renamer cannot reliably resolve Lua lexical scopes and shadowing. It performs whitespace cleanup and explains why names were preserved.
- `.dump` is text-based static inspection. It does not execute code and does not prove that code is safe.
- `.get` accepts public HTTP/HTTPS URLs only; localhost, private, loopback, link-local, reserved IPs, credential-bearing URLs, and nonstandard ports are blocked. Redirect destinations are checked too.
- For stronger isolation, deploy in a dedicated container/VM with outbound networking disabled for engine subprocesses, a read-only engine directory, and a non-root account. The Discord bot itself needs outbound network access to Discord.

## Engine provenance

The engine directories are extracted from the archives provided in the user's ChatGPT Library. Their README files and entrypoints are retained. Check each engine's upstream license and terms before redistribution or public hosting.
