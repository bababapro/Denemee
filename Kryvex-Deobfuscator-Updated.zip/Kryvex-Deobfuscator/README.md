# Kryvex Deobfuscator

Python Discord bot with prefix `.`. All bot-facing messages are in English.

## Features

- `.help` — command list.
- `.detect` — attach a Lua/Luau file or paste source after the command; reports all matching signatures plus generic structural hints.
- `.deobf` — attach a file or paste a literal Lua `loadstring("...")()` / `loadstring([[...]])()` payload. Runs only compatible local static engines. Unsupported formats receive a clearly labelled source-preserving partial result, not a false success claim.
- `.dump` — static report of declarations, identifiers, strings, constants, API references, and logging indicators.
- `.l` — with a file or pasted source, creates a static logging / anti-logging indicator report; without source, shows recent bot processing logs to the owner/authorized administrators.
- `.rename` — conservative whitespace cleanup; identifiers are not rewritten because the bundled implementation has no scope-safe Lua/Luau AST renamer.
- `.get loadstring(game:HttpGet("https://host/path/script.lua"))()` — fetches a public HTTP/HTTPS source URL and attaches it as a Lua file. Private/local network targets are blocked.

File attachments and inline source are both supported by `.detect`, `.deobf`, `.dump`, `.rename`, and `.l`. Inline `loadstring` support unwraps literal strings only; it does not evaluate Lua expressions.

## Output handling

- Every non-empty generated result is attached as a `.lua` file, including very small results.
- If the result is larger than 10,000 bytes, the first 10,000 bytes are also attached as a separate `_first_10KB.txt` preview. Discord message text has a much smaller character limit, so the preview is a file rather than 10 KB of message text.
- Configured output cap: 7 MB.

## Included local static engines

- **Clyde V2-V6** — supplied Node.js static deobfuscator.
- **Hercules 1.6.x / 2.0.0 / 2.0.1** — supplied Python deobfuscator.
- **Ironveil V1** — supplied Node.js decoder/decompiler.
- **Prometheus / WeAreDevs fork** — supplied Node.js deobfuscator.

## Tools intentionally not auto-connected

- **Luraph v14/v15**: the supplied framework relies on runtime tracing / a Luau execution harness. It is excluded; the bot does not execute uploaded scripts or bypass runtime protections.
- **LuaObfuscator Chaotic Good/Evil**: the supplied reconstruction pipeline evaluates protected loader code in a custom interpreter. It is excluded from automatic jobs.
- **MoonSec V3** and **77fuscator 0.6.1 Early Build**: supplied projects produce Lua bytecode/disassembly rather than reliably reconstructed readable Lua source. They are not advertised as readable-source deobfuscators.
- **IronBrew2**: supplied project depends on a remote Oracle API/key and is not a self-contained local adapter.
- Other packer names may be detected by signatures, but detection does not mean a compatible deobfuscator is available.

Detection is heuristic. Multiple signatures and structural hints can be reported, but a match is not proof and unknown variants may not be recognized. No tool can guarantee that every protected file can be reconstructed.

## Setup

1. Install Python 3.10+ and Node.js 18+.
2. Open a terminal in this folder.
3. Install dependencies: `python -m pip install -r requirements.txt`
4. Copy `.env.example` to `.env`.
5. Set `DISCORD_TOKEN` and `OWNER_ID` in `.env`. Optional log administrators go in `ADMIN_IDS`, comma-separated.
6. In the Discord Developer Portal, enable **Message Content Intent**.
7. Start: `python bot.py`

Never post your bot token or include it in screenshots. If it has been exposed, reset it in the Discord Developer Portal and update `.env`.

## Limits and safety

- Input: 1 MB; remote `.get`: 2 MB; output: 7 MB.
- Deobfuscation job timeout: 40 seconds; max concurrent jobs: 2.
- Uploaded Lua/Luau is not executed by the bot. Engine subprocesses are time-limited and resource-limited where supported, but for public hosting use a dedicated restricted container/VM.
- `.l` source audit detects text patterns only. It does not prove that data is being logged, and it does not intercept, disable, or transmit logs.
- `.get` accepts public HTTP/HTTPS URLs only; localhost, private, loopback, link-local, reserved IPs, credential-bearing URLs, and nonstandard ports are blocked. Redirect destinations are checked too.
- Check each supplied engine's upstream license and terms before redistribution or public hosting.
